module DesafioNINTENDO {
	exports desafionintendo;

	requires java.desktop;
	requires java.logging;
}